plugins { id("com.android.application") version "8.7.3"; id("org.jetbrains.kotlin.android") version "2.0.21" }
android {
    namespace = "lt.lumadesk"
    compileSdk = 35
    defaultConfig {
        applicationId = "lt.lumadesk"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
        ndk { abiFilters += "arm64-v8a" }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
