package lt.lumadesk

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.SystemClock
import lt.lumadesk.tracking.PoseStabilizer
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.PI

/** Native bridge: optional VITURE SDK is supplied by the builder, never ripped from an APK. */
object NativeGlasses {
    private val loaded: Boolean = runCatching { System.loadLibrary("lumadesk_glasses"); true }.getOrDefault(false)
    external fun sdkIncluded(): Boolean
    external fun open(productId: Int, fd: Int): Boolean
    external fun pose(): FloatArray?
    external fun setDisplayMode(mode: Int): Int
    external fun brightness(value: Int): Int
    external fun tint(enabled: Boolean): Int
    external fun close()
    fun ready() = loaded && runCatching { sdkIncluded() }.getOrDefault(false)
}

class VitureUsbSession(private val activity: Activity, private val status: (String) -> Unit) {
    private val manager = activity.getSystemService(Context.USB_SERVICE) as UsbManager
    private var connection: UsbDeviceConnection? = null
    private val action = "lt.lumadesk.GLASSES_PERMISSION"
    private var registered = false
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == action) connect()
        }
    }
    var trackingAvailable = false
        private set

    fun start() {
        if (!registered) {
            if (Build.VERSION.SDK_INT >= 33) activity.registerReceiver(receiver, IntentFilter(action), Context.RECEIVER_NOT_EXPORTED)
            else @Suppress("DEPRECATION") activity.registerReceiver(receiver, IntentFilter(action))
            registered = true
        }
        connect()
    }
    fun connect() {
        if (!NativeGlasses.ready()) { status("VITURE SDK nepridėtas – veikia naršyklė ir video, bet ne 3DoF."); return }
        val device = manager.deviceList.values.firstOrNull { it.vendorId == 0x35CA && (it.productId == 0x1121 || it.productId == 0x1141) }
        if (device == null) { status("Luma Pro USB kontroleris nerastas (patikrink USB-C duomenis)."); return }
        if (!manager.hasPermission(device)) {
            val intent = Intent(action).setPackage(activity.packageName)
            val pi = PendingIntent.getBroadcast(activity, 34, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            manager.requestPermission(device, pi)
            status("Reikia USB leidimo akinių IMU valdymui.")
            return
        }
        if (trackingAvailable) return
        connection?.close()
        connection = manager.openDevice(device)
        trackingAvailable = connection?.let { NativeGlasses.open(device.productId, it.fileDescriptor) } ?: false
        status(if (trackingAvailable) "Luma Pro IMU prijungtas • 3DoF aktyvus" else "VITURE SDK nepavyko inicializuoti (uždaryk SpaceWalker).")
    }
    fun readPose(): PoseStabilizer.Pose? {
        if (!trackingAvailable) return null
        val data = NativeGlasses.pose() ?: return null
        if (data.size < 7) return null
        // NWU quaternion is scalar-first: (w,x,y,z). Yaw is Z rotation; pitch Y, roll X.
        // Euler angles in callback are not used because the SDK's units aren't specified in docs.
        val qw = data[3].toDouble(); val qx = data[4].toDouble()
        val qy = data[5].toDouble(); val qz = data[6].toDouble()
        val norm = kotlin.math.sqrt(qw*qw+qx*qx+qy*qy+qz*qz)
        if (norm < 0.2 || !norm.isFinite()) return null
        val w=qw/norm; val x=qx/norm; val y=qy/norm; val z=qz/norm
        val roll  = atan2(2*(w*x+y*z), 1-2*(x*x+y*y))*180.0/PI
        val pitch = asin(max(-1.0,min(1.0,2*(w*y-z*x))))*180.0/PI
        val yaw   = atan2(2*(w*z+x*y), 1-2*(y*y+z*z))*180.0/PI
        return PoseStabilizer.Pose(yaw,pitch,roll,SystemClock.elapsedRealtimeNanos())
    }
    fun mode3D(enabled: Boolean): Int = if (trackingAvailable) NativeGlasses.setDisplayMode(if (enabled) 0x42 else 0x44) else -10
    fun brightness(level: Int): Int = if (trackingAvailable) NativeGlasses.brightness(level) else -10
    fun tint(enabled: Boolean): Int = if (trackingAvailable) NativeGlasses.tint(enabled) else -10
    fun stop() {
        if (trackingAvailable) { NativeGlasses.setDisplayMode(0x44); NativeGlasses.close() }
        trackingAvailable = false
        connection?.close(); connection = null
        if (registered) { activity.unregisterReceiver(receiver); registered = false }
    }
}
