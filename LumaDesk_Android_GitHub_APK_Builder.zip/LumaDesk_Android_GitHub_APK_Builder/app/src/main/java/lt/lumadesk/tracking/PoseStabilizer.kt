package lt.lumadesk.tracking

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot

/**
 * Source-neutral 3DoF presentation controller. Feed ONLY GLASSES orientation,
 * not phone sensor orientation. Convert the VITURE NWU axes in the bridge.
 *
 * This removes short-term jitter, recenters, and optionally follows deliberate
 * head movement. It DOES NOT solve unobservable long-term gyro yaw drift.
 */
class PoseStabilizer {
    enum class Mode { WORLD_LOCK, SMOOTH_FOLLOW, HEAD_LOCK }
    data class Pose(val yaw: Double, val pitch: Double, val roll: Double, val timestampNs: Long)
    data class Output(val yaw: Double, val pitch: Double, val roll: Double, val valid: Boolean)
    var mode: Mode = Mode.WORLD_LOCK
    var smoothingMs: Double = 25.0
    var followTimeMs: Double = 1250.0
    var followThresholdDeg: Double = 9.0
    var deadbandDeg: Double = 0.065
    var jumpRejectDeg: Double = 45.0

    private var filtered: Pose? = null
    private var anchor: Pose? = null
    private var latest: Output = Output(0.0, 0.0, 0.0, false)

    fun recenter() { anchor = filtered; latest = Output(0.0, 0.0, 0.0, filtered != null) }
    fun reset() { filtered = null; anchor = null; latest = Output(0.0, 0.0, 0.0, false) }
    fun lastOutput(): Output = latest

    fun update(next: Pose): Output {
        if (!next.yaw.isFinite() || !next.pitch.isFinite() || !next.roll.isFinite()) return latest
        val previous = filtered
        if (previous == null || next.timestampNs <= previous.timestampNs ||
            next.timestampNs - previous.timestampNs > 2_000_000_000L) {
            filtered = next; anchor = next
            latest = Output(0.0, 0.0, 0.0, true)
            return latest
        }
        val dtMs = (next.timestampNs - previous.timestampNs) / 1e6
        if (dtMs < 120.0 && hypot(shortAngle(next.yaw - previous.yaw), shortAngle(next.pitch - previous.pitch)) > jumpRejectDeg) {
            return latest // invalid IMU spike; never force recenter on it
        }
        val alpha = (1.0 - exp(-dtMs / smoothingMs.coerceAtLeast(1.0))).coerceIn(0.0, 1.0)
        fun smooth(current: Double, dest: Double): Double {
            val dif = shortAngle(dest - current)
            return if (abs(dif) < deadbandDeg) current else current + dif * alpha
        }
        val p = Pose(smooth(previous.yaw, next.yaw), smooth(previous.pitch, next.pitch), smooth(previous.roll, next.roll), next.timestampNs)
        filtered = p
        var a = anchor ?: p
        if (mode == Mode.SMOOTH_FOLLOW) {
            val followAlpha = (1.0 - exp(-dtMs / followTimeMs.coerceAtLeast(10.0))).coerceIn(0.0, 1.0)
            fun follow(centre: Double, head: Double): Double {
                val diff = shortAngle(head - centre)
                val move = if (abs(diff) > followThresholdDeg) diff - Math.copySign(followThresholdDeg, diff) else 0.0
                return centre + move * followAlpha
            }
            a = a.copy(yaw = follow(a.yaw, p.yaw), pitch = follow(a.pitch, p.pitch))
            anchor = a
        }
        latest = if (mode == Mode.HEAD_LOCK) Output(0.0, 0.0, 0.0, true)
                 else Output(shortAngle(p.yaw - a.yaw), shortAngle(p.pitch - a.pitch), shortAngle(p.roll - a.roll), true)
        return latest
    }
    companion object {
        /** Returns difference in [-180,+180), including 359 -> 1 = +2. */
        fun shortAngle(value: Double): Double = ((value + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
    }
}
