package lt.lumadesk

import android.app.Activity
import android.app.Presentation
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import lt.lumadesk.tracking.PoseStabilizer
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/**
 * Functional Android spatial-browser edition: 1–3 separate, interactive WebViews
 * or an Android local-video player, actually rendered on the USB-C external display.
 * These are NOT OS-managed windows or independent Android task virtual displays.
 * True 3D needs real SBS media and the optional VITURE SDK. This is not 2D->3D AI.
 */
data class SessionConfig(
    var panels: Int = 3,
    var scale: Float = 1f,
    var distance: Float = 1f,
    var selection: Int = 0,
    var pointerX: Float = .5f,
    var pointerY: Float = .5f,
    var cinema: Boolean = false,
    var sbs: Boolean = false,
    var videoUri: Uri? = null,
    var yawSign: Float = 1f,
    var pitchSign: Float = 1f
)

class MainActivity : Activity(), DisplayManager.DisplayListener {
    private lateinit var dm: DisplayManager
    private lateinit var usb: VitureUsbSession
    private lateinit var stabilizer: PoseStabilizer
    private val session = SessionConfig()
    private var projection: LumaPresentation? = null
    private var targetId = -1
    private lateinit var status: TextView
    private lateinit var urlField: EditText
    private lateinit var insertField: EditText
    private val handler = Handler(Looper.getMainLooper())
    private val settings by lazy { getSharedPreferences("lumadesk", MODE_PRIVATE) }

    private val tick = object : Runnable {
        override fun run() {
            usb.readPose()?.let { pose ->
                val result = stabilizer.update(pose)
                if (result.valid) projection?.setHeadOffset(
                    result.yaw * session.yawSign, result.pitch * session.pitchSign)
            }
            handler.postDelayed(this, 16)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        stabilizer = PoseStabilizer()
        session.panels = settings.getInt("panels", 3).coerceIn(1, 3)
        session.scale = settings.getFloat("scale", 1f)
        session.distance = settings.getFloat("distance", 1f)
        stabilizer.smoothingMs = settings.getInt("smoothing", 35).toDouble()
        stabilizer.mode = PoseStabilizer.Mode.entries.firstOrNull { it.name == settings.getString("mode", "WORLD_LOCK") } ?: PoseStabilizer.Mode.WORLD_LOCK
        dm.registerDisplayListener(this, handler)
        buildUi()
        usb = VitureUsbSession(this) { message -> runOnUiThread { status.text = message } }
        usb.start()
        handler.post(tick)
        connect()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun text(message: String, size: Float = 14f) = TextView(this).apply {
        text = message; textSize = size; setTextColor(Color.rgb(222, 235, 249))
        setPadding(dp(2), dp(7), dp(2), dp(7))
    }
    private fun action(label: String, run: () -> Unit) = Button(this).apply { text = label; setOnClickListener { run() } }
    private fun line(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it, LinearLayout.LayoutParams(0, dp(55), 1f)) }
    }
    private fun seek(title: String, default: Int, run: (Int) -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(text(title, 13f))
        addView(SeekBar(this@MainActivity).apply {
            max = 100; progress = default
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, n: Int, fromUser: Boolean) { if (fromUser) run(n) }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
    }
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(22))
            setBackgroundColor(Color.rgb(12, 19, 33))
        }
        root.addView(text("LumaDesk  0.2  •  Luma Pro", 24f))
        root.addView(text("Fold 6 → VITURE • realūs naršyklės paneliai ir vietinis video"))
        status = text("Ieškomas išorinis ekranas...")
        root.addView(status)
        root.addView(action("Prijungti akinius / atnaujinti") { usb.connect(); connect() })
        root.addView(text("1–3 nepriklausomos naršyklės (ne Android OS virtualūs monitoriai)", 13f))
        root.addView(line(*(1..3).map { n -> action("$n ekranai") {
            session.panels = n; settings.edit().putInt("panels", n).apply()
            projection?.showBrowsers(session.panels)
        }}.toTypedArray()))
        root.addView(line(*(1..3).map { n -> action("#${n}") { selectPanel(n - 1) }}.toTypedArray()))
        urlField = EditText(this).apply {
            hint = "URL arba paieškos frazė"; setTextColor(Color.WHITE)
            setSingleLine(true); setHintTextColor(Color.GRAY)
        }
        root.addView(urlField)
        root.addView(line(
            action("Atidaryti") { projection?.navigate(session.selection, urlField.text.toString()) },
            action("← Atgal") { projection?.goBack(session.selection) },
            action("⟳ Refresh") { projection?.reload(session.selection) }
        ))
        insertField = EditText(this).apply { hint = "Tekstas aktyviam įvesties laukui"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        root.addView(insertField)
        root.addView(action("Įrašyti tekstą aktyvioje WebView") { projection?.typeInFocused(session.selection, insertField.text.toString()) })
        root.addView(text("Trackpad: trumpas bakstelėjimas = click, judesys = žymeklis. Tiesiogiai valdo tik mūsų WebView.", 12f))
        val pad = View(this).apply {
            setBackgroundColor(Color.rgb(36, 52, 75))
            var startX = 0f; var startY = 0f
            setOnTouchListener { v, event ->
                when(event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { startX=event.x; startY=event.y; updatePointer(event.x/v.width, event.y/v.height); true }
                    MotionEvent.ACTION_MOVE -> { updatePointer(event.x/v.width, event.y/v.height); true }
                    MotionEvent.ACTION_UP -> {
                        updatePointer(event.x/v.width, event.y/v.height)
                        if (kotlin.math.abs(event.x-startX) < dp(12) && kotlin.math.abs(event.y-startY)<dp(12))
                            projection?.tap(session.pointerX, session.pointerY)
                        true
                    }
                    else -> true
                }
            }
        }
        root.addView(pad, LinearLayout.LayoutParams(-1, dp(100)))
        root.addView(line(
            action("Scroll aukštyn") { projection?.scroll(session.selection, -300) },
            action("Scroll žemyn") { projection?.scroll(session.selection, 300) }
        ))
        root.addView(seek("Panelių dydis", ((session.scale-0.6f)*100).toInt().coerceIn(0,100)) {
            session.scale = .6f + it/100f; settings.edit().putFloat("scale", session.scale).apply(); projection?.layoutPanels()
        })
        root.addView(seek("Atstumas (vaizdo mastelis)", ((session.distance - .6f)*100).toInt().coerceIn(0,100)) {
            session.distance = .6f + it/100f; settings.edit().putFloat("distance", session.distance).apply(); projection?.layoutPanels()
        })
        root.addView(line(
            action("Spatial Lock") { switchMode(PoseStabilizer.Mode.WORLD_LOCK) },
            action("Smooth Follow") { switchMode(PoseStabilizer.Mode.SMOOTH_FOLLOW) },
            action("Head Lock") { switchMode(PoseStabilizer.Mode.HEAD_LOCK) }
        ))
        root.addView(seek("3DoF stabilizavimas (kairė greičiau, dešinė ramiau)", ((stabilizer.smoothingMs-5.0)/1.45).toInt().coerceIn(0,100)) {
            stabilizer.smoothingMs = 5.0+it*1.45; settings.edit().putInt("smoothing", stabilizer.smoothingMs.toInt()).apply()
        })
        root.addView(action("Recenter – dabartinė galvos kryptis tampa centru") {
            stabilizer.recenter(); projection?.setHeadOffset(0.0, 0.0)
        })
        root.addView(text("Garsas / vaizdas", 17f))
        root.addView(action("Pasirinkti vietinį video (MP4, MKV jei palaiko Android)") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type="video/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, 11)
        })
        root.addView(line(
            action("Video ▶ / ❚❚") { projection?.togglePlayback() },
            action("Grįžti į langus") { session.cinema=false; session.sbs=false; usb.mode3D(false); projection?.showBrowsers(session.panels) }
        ))
        root.addView(line(
            action("2D / 120 Hz") { session.sbs=false; val rc=usb.mode3D(false); status.text=if(rc==0) "2D režimas įjungtas" else "2D perjungimas nepasiekiamas: SDK code $rc"; projection?.useVideoMode(false) },
            action("SBS 3D / 60 Hz") { val rc=usb.mode3D(true);session.sbs=(rc==0);status.text=if(rc==0) "SBS 3D įjungtas (reikalingas 3D video)" else "3D perjungimas nepasiekiamas: SDK code $rc"; if(rc==0)projection?.useVideoMode(true) }
        ))
        root.addView(text("SBS 3D skirtas tik jau stereoskopiniam video. Paprastas 2D video automatiškai į 3D nekonvertuojamas.", 12f))
        root.addView(seek("Akinių ryškumas (tik su oficialiu SDK)", 55) { usb.brightness((it*8/100f).toInt()) })
        root.addView(line(
            action("Lęšiai tamsūs") { usb.tint(true) },
            action("Lęšiai šviesūs") { usb.tint(false) }
        ))
        root.addView(text("Jei akinių SDK nenaudojamas, 3DoF ir SBS režimo perjungimas neveiks. Vaizdas išoriniame ekrane bei naršymas veikia be jo.", 12f))
        setContentView(ScrollView(this).apply { fillViewport=true; addView(root) })
    }
    private fun selectPanel(index: Int) { session.selection=index.coerceIn(0,session.panels-1); projection?.select(session.selection) }
    private fun switchMode(mode: PoseStabilizer.Mode) {
        stabilizer.mode=mode; settings.edit().putString("mode", mode.name).apply(); stabilizer.recenter()
        status.text="Režimas: $mode"
    }
    private fun updatePointer(x:Float,y:Float) { session.pointerX=x.coerceIn(0f,1f); session.pointerY=y.coerceIn(0f,1f); projection?.updatePointer() }
    private fun connect() {
        val output=dm.displays.firstOrNull { it.displayId!=Display.DEFAULT_DISPLAY && it.isValid }
        if (output==null) { projection?.dismiss(); projection=null; targetId=-1; status.text="Prijunk VITURE Luma Pro per USB-C (DP Alt Mode)."; return }
        if (targetId==output.displayId && projection!=null) return
        projection?.dismiss()
        try { projection=LumaPresentation(this,output,session).also { it.show() }; targetId=output.displayId
            status.text="Išorinis ekranas ${output.mode.physicalWidth}×${output.mode.physicalHeight} • ${output.name}"
        } catch(e: Exception) { projection=null; targetId=-1; status.text="Nepavyko atidaryti: ${e.message}" }
    }
    @Deprecated("Used for Android SDK 30+ file picker compatibility")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==11 && resultCode==RESULT_OK) {
            data?.data?.let { uri ->
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                session.videoUri=uri; session.cinema=true
                projection?.playVideo(uri)
            }
        }
    }
    override fun onDisplayAdded(displayId:Int) { connect() }
    override fun onDisplayRemoved(displayId:Int) { connect() }
    override fun onDisplayChanged(displayId:Int) { if (displayId==targetId) { projection?.dismiss();projection=null;targetId=-1 };connect() }
    override fun onDestroy() {
        handler.removeCallbacks(tick)
        usb.stop()
        projection?.dismiss()
        dm.unregisterDisplayListener(this)
        super.onDestroy()
    }
}

class LumaPresentation(ctx:Context, display:Display, private val cfg:SessionConfig):Presentation(ctx,display) {
    private lateinit var layer:FrameLayout
    private lateinit var parent:FrameLayout
    private lateinit var cursor:CursorView
    private var webPanels= mutableListOf<WebView>()
    private var frames=mutableListOf<FrameLayout>()
    private var video:VideoView?=null
    private var lastYaw=0.0
    private var lastPitch=0.0
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window?.decorView?.systemUiVisibility = 5894 or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        parent=FrameLayout(context).apply { setBackgroundColor(Color.rgb(5,10,20)) }
        layer=FrameLayout(context)
        parent.addView(layer,FrameLayout.LayoutParams(-1,-1))
        cursor=CursorView(context,cfg)
        parent.addView(cursor,FrameLayout.LayoutParams(-1,-1))
        setContentView(parent)
        parent.post { if (cfg.cinema && cfg.videoUri != null) playVideo(cfg.videoUri!!) else showBrowsers(cfg.panels) }
    }
    fun showBrowsers(count:Int) {
        if (!::parent.isInitialized) return
        video?.stopPlayback();video=null
        layer.removeAllViews()
        for (f in frames) { (f.parent as? FrameLayout)?.removeView(f) }
        frames.clear(); webPanels.clear()
        repeat(count) { i ->
            val frame=FrameLayout(context).apply { setBackgroundColor(Color.rgb(24,36,56)); elevation=8f }
            val title=TextView(context).apply { text="WEB ${i+1}";textSize=13f;setTextColor(Color.WHITE);setBackgroundColor(Color.rgb(35,53,82)); gravity=Gravity.CENTER_VERTICAL;setPadding(22,0,0,0) }
            frame.addView(title, FrameLayout.LayoutParams(-1, 42))
            val web=WebView(context).apply {
                settings.javaScriptEnabled=true;settings.domStorageEnabled=true
                settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW
                settings.allowFileAccess=false
                webViewClient=WebViewClient()
                webChromeClient=WebChromeClient()
                setBackgroundColor(Color.WHITE)
                loadUrl(listOf("https://www.google.com", "https://www.youtube.com", "https://www.wikipedia.org")[i])
            }
            frame.addView(web,FrameLayout.LayoutParams(-1,-1).apply { topMargin=42 })
            layer.addView(frame)
            frames.add(frame);webPanels.add(web)
        }
        cfg.cinema=false
        layoutPanels()
    }
    fun layoutPanels() {
        if(!::parent.isInitialized || frames.isEmpty())return
        parent.post {
            val w=parent.width.toFloat();val h=parent.height.toFloat()
            if (w<1 || h<1)return@post
            val n=frames.size
            val factor=(cfg.scale/cfg.distance).coerceIn(.55f,1.55f)
            val gap=w*.016f
            val panelW=((w*.92f-gap*(n-1))/n*factor).toInt()
            val panelH=(h*.79f*factor).toInt().coerceAtMost((h*.92f).toInt())
            val fullW=panelW*n+gap.toInt()*(n-1)
            val startX=(w-fullW)/2f
            frames.forEachIndexed { i,frame ->
                frame.layoutParams=FrameLayout.LayoutParams(panelW,panelH).apply { leftMargin=(startX+i*(panelW+gap)).toInt();topMargin=((h-panelH)/2f).toInt() }
            }
            setHeadOffset(lastYaw,lastPitch)
        }
    }
    fun setHeadOffset(yaw:Double,pitch:Double) {
        lastYaw=yaw;lastPitch=pitch
        if(!::parent.isInitialized)return
        // 2D angular workspace pan. A production stereo renderer needs OpenGL/Metal perspective projection.
        layer.translationX=(-(if(cfg.cinema) 0.0 else yaw)*parent.width/52.0).toFloat().coerceIn(-parent.width.toFloat(),parent.width.toFloat())
        layer.translationY=((if(cfg.cinema) 0.0 else pitch)*parent.height/42.0).toFloat().coerceIn(-parent.height.toFloat(),parent.height.toFloat())
    }
    fun select(index:Int) { frames.forEachIndexed { i,f -> f.alpha=if(i==index) 1f else .90f } }
    fun navigate(index:Int,entry:String) {
        val q=entry.trim(); if(q.isBlank())return
        val dest=if(q.contains(".") && !q.contains(" ")) (if(q.startsWith("https://") || q.startsWith("http://"))q else "https://$q")
        else "https://www.google.com/search?q="+Uri.encode(q)
        webPanels.getOrNull(index)?.loadUrl(dest)
    }
    fun reload(index:Int) { webPanels.getOrNull(index)?.reload() }
    fun goBack(index:Int) { webPanels.getOrNull(index)?.let { if(it.canGoBack())it.goBack() } }
    fun scroll(index:Int,dy:Int) { webPanels.getOrNull(index)?.let{ it.scrollBy(0,dy) } }
    fun typeInFocused(index:Int,str:String) {
        // Works for many simple forms; cross-origin iframes/protected editors can ignore it.
        val quoted=JSONObject.quote(str)
        webPanels.getOrNull(index)?.evaluateJavascript("(function(){let el=document.activeElement;if(el && ('value' in el)){el.value=$quoted;el.dispatchEvent(new Event('input',{bubbles:true}));return true;}return false;})()",null)
    }
    fun updatePointer(){ if(::cursor.isInitialized)cursor.invalidate() }
    fun tap(nx:Float,ny:Float) {
        val px=parent.width*nx;val py=parent.height*ny
        frames.forEachIndexed {index, frame ->
            val fx=frame.x+layer.translationX;val fy=frame.y+layer.translationY
            if(px in fx..(fx+frame.width) && py in (fy+42)..(fy+frame.height)) {
                cfg.selection=index
                val target=webPanels[index]
                val x=px-fx;val y=py-fy-42
                val whenNs=android.os.SystemClock.uptimeMillis()
                val down=MotionEvent.obtain(whenNs,whenNs,MotionEvent.ACTION_DOWN,x,y,0)
                val up=MotionEvent.obtain(whenNs,whenNs+50,MotionEvent.ACTION_UP,x,y,0)
                target.dispatchTouchEvent(down);target.dispatchTouchEvent(up)
                down.recycle();up.recycle()
                return
            }
        }
    }
    fun playVideo(uri:Uri) {
        if(!::parent.isInitialized)return
        cfg.videoUri=uri
        layer.removeAllViews();frames.clear();webPanels.forEach { it.stopLoading(); it.destroy() };webPanels.clear()
        video=VideoView(context).apply {
            setVideoURI(uri)
            setOnPreparedListener { mp -> mp.isLooping=false;start() }
            setOnErrorListener { _,_,_->false }
        }
        layer.addView(video,FrameLayout.LayoutParams(-1,-1))
    }
    fun useVideoMode(sbs:Boolean) {
        cfg.sbs=sbs
        // Android will resize the Presentation after physical display-mode change.
        cfg.videoUri?.let {if(video==null)playVideo(it)}
    }
    fun togglePlayback() { video?.let{if(it.isPlaying) it.pause() else it.start()} }
    override fun dismiss() {
        video?.stopPlayback()
        webPanels.forEach {it.stopLoading(); it.destroy()}
        super.dismiss()
    }
}

class CursorView(context:Context,private val config:SessionConfig):View(context) {
    private val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.CYAN }
    override fun onDraw(c:Canvas) {
        super.onDraw(c)
        val x=width*config.pointerX;val y=height*config.pointerY
        paint.style=Paint.Style.STROKE;paint.strokeWidth=3f
        c.drawCircle(x,y,12f,paint)
    }
}
