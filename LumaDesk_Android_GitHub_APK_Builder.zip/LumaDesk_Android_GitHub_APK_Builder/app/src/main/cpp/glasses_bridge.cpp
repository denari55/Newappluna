#include <jni.h>
#include <array>
#include <mutex>
#include <cstdint>

#ifdef LUMADESK_WITH_SDK
#include "viture_glasses_provider.h"
#include "viture_device.h"
#include "viture_protocol_public.h"
#endif

static std::mutex pose_mutex;
static std::array<float,7> latest_pose{};
static bool has_pose = false;
#ifdef LUMADESK_WITH_SDK
static XRDeviceProviderHandle sdk_handle = nullptr;
static bool streaming = false;
static std::mutex session_mutex;

static void onPose(float* data, uint64_t) {
    if (!data) return;
    std::lock_guard<std::mutex> g(pose_mutex);
    for (int i=0;i<7;i++) latest_pose[i] = data[i];
    has_pose = true;
}
static void stopLocked() {
    if (!sdk_handle) return;
    if (streaming) {
        xr_device_provider_close_imu(sdk_handle, VITURE_IMU_MODE_POSE);
        xr_device_provider_stop(sdk_handle);
        streaming = false;
    }
    xr_device_provider_shutdown(sdk_handle);
    xr_device_provider_destroy(sdk_handle);
    sdk_handle = nullptr;
    std::lock_guard<std::mutex> lock(pose_mutex);
    has_pose = false;
}
#endif

extern "C" JNIEXPORT jboolean JNICALL
Java_lt_lumadesk_NativeGlasses_sdkIncluded(JNIEnv*, jobject) {
#ifdef LUMADESK_WITH_SDK
    return JNI_TRUE;
#else
    return JNI_FALSE;
#endif
}

extern "C" JNIEXPORT jboolean JNICALL
Java_lt_lumadesk_NativeGlasses_open(JNIEnv*, jobject, jint productId, jint fd) {
#ifdef LUMADESK_WITH_SDK
    std::lock_guard<std::mutex> lock(session_mutex);
    stopLocked();
    if (fd < 0 || (productId != 0x1121 && productId != 0x1141)) return JNI_FALSE;
    sdk_handle = xr_device_provider_create(productId, fd);
    if (!sdk_handle) return JNI_FALSE;
    int rc = xr_device_provider_register_imu_pose_callback(sdk_handle, onPose);
    if (rc == 0) rc = xr_device_provider_initialize(sdk_handle, nullptr, nullptr);
    if (rc == 0) rc = xr_device_provider_start(sdk_handle);
    if (rc == 0) {
        streaming = true;
        // Prefer a rate known to work on Luma Pro; SDK may negotiate lower.
        rc = xr_device_provider_open_imu(sdk_handle, VITURE_IMU_MODE_POSE, VITURE_IMU_FREQUENCY_MEDIUM_HIGH);
    }
    if (rc != 0) { stopLocked(); return JNI_FALSE; }
    return JNI_TRUE;
#else
    (void)productId; (void)fd;
    return JNI_FALSE;
#endif
}

extern "C" JNIEXPORT jfloatArray JNICALL
Java_lt_lumadesk_NativeGlasses_pose(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> lock(pose_mutex);
    if (!has_pose) return nullptr;
    jfloatArray out = env->NewFloatArray(7);
    if (out) env->SetFloatArrayRegion(out, 0, 7, latest_pose.data());
    return out;
}

extern "C" JNIEXPORT jint JNICALL
Java_lt_lumadesk_NativeGlasses_setDisplayMode(JNIEnv*, jobject, jint mode) {
#ifdef LUMADESK_WITH_SDK
    std::lock_guard<std::mutex> lock(session_mutex);
    if (!sdk_handle || !streaming) return -10;
    if (mode != 0x42 && mode != 0x44 && mode != 0x41) return -1;
    return xr_device_provider_set_display_mode(sdk_handle, mode);
#else
    (void)mode; return -4;
#endif
}

extern "C" JNIEXPORT jint JNICALL
Java_lt_lumadesk_NativeGlasses_brightness(JNIEnv*, jobject, jint value) {
#ifdef LUMADESK_WITH_SDK
    std::lock_guard<std::mutex> lock(session_mutex);
    if (!sdk_handle || !streaming) return -10;
    return xr_device_provider_set_brightness_level(sdk_handle, value < 0 ? 0 : (value > 8 ? 8 : value));
#else
    (void)value; return -4;
#endif
}

extern "C" JNIEXPORT jint JNICALL
Java_lt_lumadesk_NativeGlasses_tint(JNIEnv*, jobject, jboolean enabled) {
#ifdef LUMADESK_WITH_SDK
    std::lock_guard<std::mutex> lock(session_mutex);
    if (!sdk_handle || !streaming) return -10;
    return xr_device_provider_set_film_mode(sdk_handle, enabled ? 1.f : 0.f);
#else
    (void)enabled; return -4;
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_lt_lumadesk_NativeGlasses_close(JNIEnv*, jobject) {
#ifdef LUMADESK_WITH_SDK
    std::lock_guard<std::mutex> lock(session_mutex);
    stopLocked();
#endif
}
