# LumaDesk Android v0.2: automatic APK build

This is **prototype** source, not a finished XR spatial desktop.
The included workflow builds an Android `app-debug.apk` on GitHub Actions. This package contains no unlicensed third-party binaries.

## Using GitHub Actions

1. Create an empty GitHub repository (private is fine).
2. Upload **the contents of this folder to the repository root**, including `.github/workflows/build-apk.yml`.
3. Open **Actions > Build LumaDesk Android APK > Run workflow** (or push to the main branch).
4. When the job succeeds, open its **Artifacts** and download **LumaDesk-Android-debug-APK**.
5. Unzip the downloaded artifact, copy `app-debug.apk` to Galaxy Z Fold 6, and install. Android may prompt to allow installation from the selected file manager.

## Current limitations

- This has not been compiled or tested in this environment; the CI workflow is prepared but unverified.
- Without official VITURE SDK native libraries, compilation uses an explicit **no-device stub**: USB IMU/head-tracking, brightness/tint, SBS mode switching are unavailable.
- Android browser WebView panels can be displayed on an external monitor, but these are NOT independent virtual Android OS app screens.
- No AI 2D-to-3D conversion, no true stereoscopic spatial renderer.
- Debug APK is for personal testing, not release distribution.

Build uses Android Gradle Plugin 8.7.3 / Gradle 8.9 / Java 17 / Android API 35 / NDK 27 and CMake 3.22.1.
